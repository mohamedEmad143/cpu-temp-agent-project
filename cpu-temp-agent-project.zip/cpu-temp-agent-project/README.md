# System Monitor Dashboard

<!-- This README.md file serves as the primary documentation for the project. It explains the project's purpose, features, how to set it up, and what each file does. It's the first place a new developer should look to understand the system. -->

This project is a real-time system monitoring dashboard that displays metrics for CPU, memory, disk, network, GPU, and running processes. It features a web-based frontend served by a Node.js backend, which collects data from platform-specific scripts and a dedicated C# agent for hardware temperatures on Windows.

 <!-- It's a good idea to add a screenshot of your UI here -->

## Features

- **Real-time Metrics**: View live system data pushed from the server via WebSockets.
- **Cross-Platform**: Works on Windows and Linux, using dedicated scripts for each OS.
- **Hardware Temperatures**: A separate C# agent for Windows provides accurate CPU and GPU temperatures using `LibreHardwareMonitor`.
- **Rich UI**: Modern, responsive dashboard with charts (using Chart.js), tables, and key performance indicators.
- **Data Export**: Export historical metrics in various formats (JSONL, CSV, TXT, HTML, PDF).
- **Customizable**: Adjust update frequency, toggle dark mode, and show/hide panels directly from the UI.

## Project Structure

The project is composed of a Node.js backend, a C# hardware agent (for Windows), and a web frontend.

```
cpu-temp-agent/
├── bin/Debug/net8.0/           # Compiled C# Agent output
│   ├── CpuTempAgent.exe        # The hardware temperature agent
│   ├── LibreHardwareMonitorLib.dll # Dependency for hardware access
│   └── ...
├── history/
│   └── metrics.jsonl           # Stores historical metrics data
├── node_modules/               # Node.js dependencies
├── public/                     # Frontend static files (HTML, CSS, JS)
│   ├── index.html              # Main dashboard page
│   ├── main.js                 # Frontend logic, WebSocket handling, UI updates
│   └── styles.css              # Styles for the dashboard
├── scripts/
│   ├── linux/                  # Metrics collection scripts for Linux
│   │   ├── metrics.sh
│   │   ├── processes.sh
│   │   ├── gpu.sh
│   │   └── disk_smart.sh
│   └── windows/                # Metrics collection scripts for Windows (PowerShell)
│       ├── metrics.ps1
│       ├── processes.ps1
│       ├── gpu.ps1
│       └── disk_smart.ps1
├── src/
│   ├── Program.cs              # Source code for the C# CpuTempAgent
│   └── server.js               # The main Node.js backend server
└── README.md                   # This file
```

## Core Components

### 1. Node.js Backend (`src/server.js`)

- **Role**: The central hub of the application.
- **Frameworks**: Built with Express.js for HTTP endpoints and ws for WebSocket communication.
- **Functionality**:
  - Serves the static frontend from the `/public` directory.
  - Orchestrates metric collection by running scripts from the `/scripts` directory based on the host OS.
  - On Windows, it fetches temperature and utilization data from the C# `CpuTempAgent`.
  - Broadcasts collected metrics to all connected dashboard clients via WebSockets.
  - Persists metrics to `history/metrics.jsonl` for historical review.
  - Provides HTTP endpoints:
    - `/metrics`: Get the latest metrics snapshot.
    - `/metrics-history`: Get all historical data.
    - `/export/:format`: Download historical data as `jsonl`, `csv`, `txt`, `html`, or `pdf`.

### 2. C# Temperature Agent (`CpuTempAgent.exe`)

- **Role**: A Windows-only helper application to access low-level hardware sensor data.
- **Frameworks**: .NET 8, `LibreHardwareMonitorLib` for sensor access.
- **Functionality**:
  - Must be **run as Administrator** to access hardware sensors.
  - Reads CPU and GPU temperatures.
  - Reads CPU and GPU utilization using Windows Performance Counters for higher accuracy.
  - Exposes the collected data via a simple HTTP server on `http://localhost:8085/cpu-temp`.

### 3. Frontend (`public/`)

- **Role**: The user-facing dashboard.
- **Technology**: Vanilla HTML, CSS, and JavaScript, with Chart.js for data visualization.
- **Functionality**:
  - Establishes a WebSocket connection to the Node.js backend.
  - Receives real-time metric updates and dynamically updates all UI components (KPIs, charts, tables).
  - Allows users to customize the UI (update speed, dark mode, visible panels) and persists settings in `localStorage`.
  - Provides sorting for the "Top Processes" table.

### 4. Metrics Scripts (`scripts/`)

- **Role**: Platform-specific data collectors.
- **Technology**: Bash for Linux, PowerShell for Windows.
- **Functionality**:
  - Each script is responsible for a specific piece of data (e.g., CPU usage, top processes, disk health).
  - They output their findings as a JSON string to standard output.
  - The Node.js server executes these scripts and parses their JSON output.
  - For disk health (`disk_smart`), the scripts attempt to use `smartctl` if it's installed on the system.

## Setup and Installation

### Prerequisites

- Node.js (v18 or newer recommended)
- .NET 8 SDK (for building or running the C# agent on Windows)
- (Optional) For disk health, install `smartmontools` (`choco install smartmontools` on Windows, `apt-get install smartmontools` on Debian/Ubuntu).

### Running the Application

1.  **Clone the repository:**
    ```bash
    git clone <your-repo-url>
    cd cpu-temp-agent
    ```

2.  **Install Node.js dependencies:**
    ```bash
    npm install
    ```

3.  **(Windows Only) Run the C# Temperature Agent:**
    - Open a new terminal **as an Administrator**.
    - Navigate to the agent's directory and run it. If you haven't built it, you can run from the source project.
    ```powershell
    # Option A: Run from source
    cd src
    dotnet run --project Program.cs

    # Option B: Run the pre-compiled executable
    cd bin/Debug/net8.0
    ./CpuTempAgent.exe
    ```
    You should see the message: `CPU temperature agent running at http://localhost:8085/cpu-temp`. Leave this terminal running.

4.  **Start the Node.js Backend Server:**
    - In your original terminal (no admin rights needed), run:
    ```bash
    npm start
    ```
    You should see: `System monitor backend listening on http://localhost:8090`.

5.  **Open the Dashboard:**
    - Open your web browser and navigate to **http://localhost:8090**.

## File Descriptions

| File / Directory | Description |
| --- | --- |
| `src/server.js` | Main Node.js application server. Handles API, WebSockets, and metric collection. |
| `src/Program.cs` | C# source for the Windows hardware temperature agent. |
| `public/index.html` | The single-page HTML structure for the dashboard. |
| `public/main.js` | Frontend JavaScript for WebSocket handling, UI updates, and Chart.js integration. |
| `public/styles.css` | All CSS for styling the dashboard UI. |
| `scripts/**/*.ps1` | PowerShell scripts for collecting metrics on Windows. |
| `scripts/**/*.sh` | Bash scripts for collecting metrics on Linux. |
| `bin/Debug/net8.0/` | Contains the compiled C# agent and its dependencies. |
| `CpuTempAgent.exe` | The executable for the Windows hardware agent. |
| `LibreHardwareMonitorLib.dll` | A required library for the C# agent to interface with hardware sensors. |
| `HidSharp.dll` | A dependency of `LibreHardwareMonitorLib`. |
| `*.deps.json` | .NET dependency file, listing packages required by the C# agent. |
| `System.*.dll` | Standard .NET libraries used by the C# agent. |

---

*This README was generated to provide a comprehensive overview of the project components and functionality.*