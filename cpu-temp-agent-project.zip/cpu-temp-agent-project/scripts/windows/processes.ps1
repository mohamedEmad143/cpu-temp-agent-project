Param()

$ErrorActionPreference = "Stop"

# Per-process CPU% using Get-Process sampled twice.
# CPU% ≈ (ΔCPU_seconds / interval_seconds) * 100 / num_cores

$intervalSeconds = 0.5
$sample1 = Get-Process | Select-Object Id, ProcessName, CPU, WorkingSet64
Start-Sleep -Seconds $intervalSeconds
$sample2 = Get-Process | Select-Object Id, ProcessName, CPU, WorkingSet64

$cores = (Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors
if (-not $cores -or $cores -lt 1) { $cores = 1 }

$map2 = @{}
foreach ($p in $sample2) {
    $map2[$p.Id] = $p
}

$list = @()
foreach ($p1 in $sample1) {
    if (-not $map2.ContainsKey($p1.Id)) { continue }
    $p2 = $map2[$p1.Id]

    if ($null -eq $p1.CPU -or $null -eq $p2.CPU) { continue }

    $deltaCpu = [double]$p2.CPU - [double]$p1.CPU
    if ($deltaCpu -lt 0) { continue }

    $cpuPct = 0.0
    if ($intervalSeconds -gt 0) {
        $cpuPct = ($deltaCpu / $intervalSeconds) * 100.0 / $cores
    }

    $list += [PSCustomObject]@{
        pid       = $p2.Id
        name      = $p2.ProcessName
        cpu_pct   = [math]::Round($cpuPct, 1)
        mem_bytes = [int64]$p2.WorkingSet64
    }
}

$list |
    Sort-Object cpu_pct -Descending |
    Select-Object -First 20 |
    ConvertTo-Json -Depth 3

