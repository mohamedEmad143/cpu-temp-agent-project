Param()

$ErrorActionPreference = "Stop"

# GPU utilization metrics for Windows.
# Uses performance counters: \GPU Engine(*)\Utilization Percentage
# Aggregates per GPU index (best-effort; many engines may map to same physical GPU).

try {
    $counters = Get-Counter '\GPU Engine(*)\Utilization Percentage'
} catch {
    # If counters are unavailable, emit empty array.
    '{ "gpus": [] }'
    return
}

$groups = @{}

foreach ($sample in $counters.CounterSamples) {
    $path = $sample.Path
    $value = [double]$sample.CookedValue

    # Typical instance name looks like: GPU Engine(pid_1234_luid_0x000..._engtype_3D)
    # We group all engines into a single GPU0 for now (academic simplification).
    $key = "GPU 0"

    if (-not $groups.ContainsKey($key)) {
        $groups[$key] = [PSCustomObject]@{
            name        = $key
            count       = 0
            totalValue  = 0.0
        }
    }

    $g = $groups[$key]
    $g.count++
    $g.totalValue += $value
}

$result = @()
foreach ($entry in $groups.Values) {
    $avg = if ($entry.count -gt 0) { $entry.totalValue / $entry.count } else { 0.0 }
    $result += [PSCustomObject]@{
        name         = $entry.name
        utilization  = [math]::Round($avg, 1)
    }
}

@{ gpus = $result } | ConvertTo-Json -Depth 3


