Param()

# This script checks the health of physical disks on Windows.
# It outputs a JSON array of objects, each containing a device identifier and a health status.
# This information is then merged into the main metrics payload by `server.js`.

$ErrorActionPreference = "Stop"

# This function attempts to get the S.M.A.R.T. health status using the `smartctl.exe` tool.
# `smartctl` (from the smartmontools package) provides detailed and accurate health data.
function Get-SmartHealthFromSmartctl {
    # It takes the device ID (e.g., \\.\PHYSICALDRIVE0) as input.
    param($deviceId)
    try {
        # Execute smartctl with the -H flag to get the health summary.
        # Errors are redirected to $null to handle cases where the tool isn't installed or fails.
        $output = & smartctl -H $deviceId 2>$null
        if ($LASTEXITCODE -ne 0 -or -not $output) {
            return $null
        }
        $line = $output | Where-Object { $_ -match 'SMART overall-health' }
        if (-not $line) { return $null }
        if ($line -match 'PASSED') { return 'PASSED' }
        if ($line -match 'FAILED') { return 'FAILED' }
        return 'UNKNOWN'
    } catch {
        # If any other error occurs, return null to indicate failure.
        return $null
    }
}

$results = @()

# First, check if `smartctl.exe` is available in the system's PATH.
if (Get-Command smartctl -ErrorAction SilentlyContinue) {
    # If it is, iterate through all physical disk drives found by WMI.
    $drives = Get-CimInstance Win32_DiskDrive
    foreach ($d in $drives) {
        $health = Get-SmartHealthFromSmartctl -deviceId $d.DeviceID
        if (-not $health) { $health = 'UNKNOWN' }
        $results += [PSCustomObject]@{
            device  = $d.DeviceID
            health  = $health
        }
    }
} else {
    # FALLBACK: If `smartctl` is not found, try to use the built-in PowerShell `Get-PhysicalDisk` cmdlet.
    # This provides a more basic health status (e.g., "Healthy", "Warning").
    # This is better than nothing but less detailed than S.M.A.R.T.
    try {
        if (Get-Command Get-PhysicalDisk -ErrorAction SilentlyContinue) {
            $phys = Get-PhysicalDisk
            foreach ($p in $phys) {
                $results += [PSCustomObject]@{
                    device = $p.FriendlyName
                    health = $p.HealthStatus
                }
            }
        }
    } catch {
        # Ignore errors if the Storage cmdlets are also unavailable or fail.
    }
}

# Convert the final array of results into a JSON string and print it to standard output.
$results | ConvertTo-Json -Depth 4
