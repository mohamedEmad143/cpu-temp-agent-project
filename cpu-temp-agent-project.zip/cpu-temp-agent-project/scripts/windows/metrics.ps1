Param()

$ErrorActionPreference = "Stop"

# CPU utilization (total + per-core) using Get-Counter
$cpuCounters = Get-Counter '\Processor(*)\% Processor Time'
$totalSample = $cpuCounters.CounterSamples | Where-Object { $_.InstanceName -eq '_Total' } | Select-Object -First 1
$cpuTotal = if ($null -ne $totalSample) { [math]::Round($totalSample.CookedValue, 1) } else { 0.0 }

$coreUsages = @()
foreach ($cs in $cpuCounters.CounterSamples) {
    if ($cs.InstanceName -ne "_Total") {
        $coreUsages += [math]::Round($cs.CookedValue, 1)
    }
}

# Memory usage using CIM
$os = Get-CimInstance Win32_OperatingSystem
$totalKB = [int64]$os.TotalVisibleMemorySize
$freeKB = [int64]$os.FreePhysicalMemory
$usedKB = $totalKB - $freeKB

# Disk usage using Get-CimInstance
$drives = Get-CimInstance Win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 }
$diskObjects = @()
foreach ($d in $drives) {
    $diskObjects += [PSCustomObject]@{
        filesystem = $d.DeviceID
        size       = [int64]$d.Size
        used       = [int64]($d.Size - $d.FreeSpace)
        available  = [int64]$d.FreeSpace
        mount      = $d.DeviceID
    }
}

# Network usage using Get-Counter (bytes sent/received per interface)
$netBytes = Get-Counter '\Network Interface(*)\Bytes Received/sec','\Network Interface(*)\Bytes Sent/sec'
$rx = @{}
$tx = @{}
for ($i = 0; $i -lt $netBytes.CounterSamples.Count; $i++) {
    $cs = $netBytes.CounterSamples[$i]
    $parts = $cs.Path.Split("\")
    $counterName = $parts[-1]
    $instance = $parts[-2].Trim(")")
    $instance = $instance.Substring($instance.IndexOf("(") + 1)

    if ($counterName -like '*Bytes Received*') {
        $rx[$instance] = [int64]$cs.CookedValue
    } elseif ($counterName -like '*Bytes Sent*') {
        $tx[$instance] = [int64]$cs.CookedValue
    }
}

$netObjects = @()
foreach ($iface in $rx.Keys) {
    $netObjects += [PSCustomObject]@{
        iface    = $iface
        rx_bytes = $rx[$iface]
        tx_bytes = $(if ($tx.ContainsKey($iface)) { $tx[$iface] } else { 0 })
    }
}

$obj = [PSCustomObject]@{
    platform = "windows"
    cpu      = @{
        total_usage = $cpuTotal
        cores       = $coreUsages
    }
    memory   = @{
        total_kb     = $totalKB
        used_kb      = $usedKB
        available_kb = $freeKB
    }
    disks    = $diskObjects
    network  = $netObjects
}

$obj | ConvertTo-Json -Depth 5


