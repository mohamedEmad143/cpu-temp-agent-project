const http = require('http');
const { exec } = require('child_process');
const path = require('path');

// Define the port for the HTTP server
const PORT = 8085;

// Determine the directory where the shell scripts are located.
// This assumes 'server.js' is in the root and 'scripts/linux' is relative to it.
const SCRIPT_DIR = path.join(__dirname, 'scripts', 'linux');

// Define the CPU temperature alert threshold (same as in the C# agent)
const CPU_ALERT_TEMP = 80;

// Variable to store the latest collected metrics
let latestMetrics = {};

/**
 * Executes a shell script and attempts to parse its output as JSON.
 * @param {string} scriptName The name of the script file (e.g., 'metrics.sh').
 * @returns {Promise<object|Array>} A promise that resolves with the parsed JSON output,
 *                                  or an empty object/array if an error occurs or parsing fails.
 */
async function executeScript(scriptName) {
    return new Promise(resolve => {
        const scriptPath = path.join(SCRIPT_DIR, scriptName);
        // Execute the script using bash. Errors are redirected to stderr.
        exec(`bash ${scriptPath}`, { timeout: 5000 }, (error, stdout, stderr) => {
            if (error) {
                console.error(`[ERROR] Script '${scriptName}' failed: ${error.message}`);
                console.error(`[STDERR] ${stderr}`);
                // Return an empty object or array based on expected script output structure
                resolve(scriptName === 'disk_smart.sh' || scriptName === 'processes.sh' ? [] : {});
                return;
            }
            try {
                // Attempt to parse the stdout as JSON
                const jsonOutput = JSON.parse(stdout);
                resolve(jsonOutput);
            } catch (parseError) {
                console.error(`[ERROR] Failed to parse JSON from '${scriptName}': ${parseError.message}`);
                console.error(`[STDOUT] ${stdout}`); // Log stdout for debugging malformed JSON
                resolve(scriptName === 'disk_smart.sh' || scriptName === 'processes.sh' ? [] : {});
            }
        });
    });
}

/**
 * Retrieves CPU and GPU temperatures using the 'sensors' command (lm_sensors).
 * This function parses the JSON output of 'sensors -j'.
 * @returns {Promise<{cpu_temp: number|null, gpu_temp: number|null}>}
 */
async function getTemperaturesFromSensors() {
    return new Promise(resolve => {
        exec('sensors -j', { timeout: 5000 }, (error, stdout, stderr) => {
            if (error) {
                console.error(`[ERROR] 'sensors -j' failed: ${error.message}`);
                console.error(`[STDERR] ${stderr}`);
                resolve({ cpu_temp: null, gpu_temp: null });
                return;
            }
            try {
                const sensorsData = JSON.parse(stdout);
                let cpuTemp = null;
                let gpuTemp = null;

                // Iterate through sensor chips to find CPU and GPU temperatures
                for (const chipName in sensorsData) {
                    // Common CPU temperature chip names
                    if (chipName.toLowerCase().includes('coretemp') || chipName.toLowerCase().includes('k10temp')) {
                        for (const featureName in sensorsData[chipName]) {
                            if (featureName.toLowerCase().includes('temp')) {
                                // Look for 'temp1_input' or 'temp_input'
                                const tempValue = sensorsData[chipName][featureName]['temp1_input'] || sensorsData[chipName][featureName]['temp_input'];
                                if (typeof tempValue === 'number') {
                                    cpuTemp = Math.max(cpuTemp || 0, tempValue); // Take the maximum if multiple core temps are found
                                }
                            }
                        }
                    }
                    // Common GPU temperature chip names (e.g., amdgpu, nouveau for open-source drivers)
                    if (chipName.toLowerCase().includes('amdgpu') || chipName.toLowerCase().includes('nouveau')) {
                         for (const featureName in sensorsData[chipName]) {
                            if (featureName.toLowerCase().includes('temp')) {
                                const tempValue = sensorsData[chipName][featureName]['temp1_input'] || sensorsData[chipName][featureName]['temp_input'];
                                if (typeof tempValue === 'number') {
                                    gpuTemp = Math.max(gpuTemp || 0, tempValue);
                                }
                            }
                        }
                    }
                }
                resolve({ cpu_temp: cpuTemp, gpu_temp: gpuTemp });
            } catch (parseError) {
                console.error(`[ERROR] Failed to parse 'sensors -j' output: ${parseError.message}`);
                resolve({ cpu_temp: null, gpu_temp: null });
            }
        });
    });
}

/**
 * Background task to periodically update system metrics.
 * This function runs indefinitely, collecting data every 2 seconds.
 */
async function updateMetricsLoop() {
    while (true) {
        // Execute all scripts and sensor commands concurrently
        const [metrics, diskSmart, processes, gpuMetrics, sensorTemps] = await Promise.all([
            executeScript('metrics.sh'),
            executeScript('disk_smart.sh'),
            executeScript('processes.sh'),
            executeScript('gpu.sh'), // This script handles NVIDIA GPUs via nvidia-smi
            getTemperaturesFromSensors() // This handles CPU and other GPU temps via lm_sensors
        ]);

        // Merge all collected data into a single object
        latestMetrics = {
            ...metrics, // Contains platform, cpu, memory, disks, network from metrics.sh
            disk_smart: diskSmart,
            processes: processes,
            gpus: gpuMetrics.gpus || [], // Use the 'gpus' array from gpu.sh
            cpu_temp: sensorTemps.cpu_temp,
            // Prioritize GPU temp from nvidia-smi if available, otherwise use lm_sensors
            gpu_temp: (gpuMetrics.gpus && gpuMetrics.gpus.length > 0 && gpuMetrics.gpus[0].temp_c) !== undefined
                        ? gpuMetrics.gpus[0].temp_c
                        : sensorTemps.gpu_temp
        };

        // Apply the CPU temperature alert logic
        latestMetrics.cpu_temp_alert = latestMetrics.cpu_temp !== null && latestMetrics.cpu_temp >= CPU_ALERT_TEMP;

        console.log('Metrics updated.');
        await new Promise(resolve => setTimeout(resolve, 2000)); // Wait for 2 seconds before next update
    }
}

// Start the background metric update loop
updateMetricsLoop().catch(console.error);

// Create the HTTP server
const server = http.createServer((req, res) => {
    // Set CORS header to allow requests from any origin (e.g., a web frontend)
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Content-Type', 'application/json');

    // Handle requests to the /cpu-temp endpoint
    if (req.method === 'GET' && req.url === '/cpu-temp') {
        res.writeHead(200);
        res.end(JSON.stringify(latestMetrics, null, 2)); // Send the latest metrics as JSON
    } else {
        // For any other request, return a 404 Not Found error
        res.writeHead(404);
        res.end(JSON.stringify({ error: 'Not Found', message: 'Endpoint not found. Try /cpu-temp' }));
    }
});

// Start listening for incoming HTTP requests
server.listen(PORT, () => {
    console.log(`✅ Linux Agent running at http://localhost:${PORT}/cpu-temp`);
});

// Handle graceful shutdown on Ctrl+C
process.on('SIGINT', () => {
    console.log('Shutting down agent...');
    server.close(() => {
        console.log('Agent shut down.');
        process.exit(0);
    });
});