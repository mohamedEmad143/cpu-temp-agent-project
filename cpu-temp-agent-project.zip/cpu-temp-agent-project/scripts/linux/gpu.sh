#!/usr/bin/env bash
set -euo pipefail

# GPU metrics for Linux.
# Prefer nvidia-smi when available; otherwise emit empty gpus array.

if command -v nvidia-smi >/dev/null 2>&1; then
  # Query: name, temperature.gpu, utilization.gpu, memory.used, memory.total
  mapfile -t lines < <(nvidia-smi --query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total --format=csv,noheader,nounits)

  json="["
  idx=0
  for line in "${lines[@]}"; do
    IFS=',' read -r name temp util mem_used mem_total <<<"$line"
    name_trimmed=$(echo "$name" | sed 's/^ *//;s/ *$//')
    if [ "$idx" -gt 0 ]; then
      json+=","
    fi
    json+="{\"name\":\"${name_trimmed//\"/\\\"}\",\"vendor\":\"nvidia\",\"index\":$idx,\"temp_c\":$temp,\"utilization\":$util,\"mem_used_mb\":$mem_used,\"mem_total_mb\":$mem_total}"
    idx=$((idx + 1))
  done
  json+="]"

  printf '{\"gpus\":%s}' "$json"
else
  # TODO: add support for AMD/Intel via sensors/rocm-smi if present.
  printf '{\"gpus\":[]}'
fi