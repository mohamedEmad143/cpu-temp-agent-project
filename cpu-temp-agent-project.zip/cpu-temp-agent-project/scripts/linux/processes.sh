#!/usr/bin/env bash
set -euo pipefail

# Top processes by CPU
# Output JSON array of { pid, name, cpu_pct, mem_bytes }
# cpu_pct is the %CPU reported by ps (percentage of one logical CPU).

# rss (resident set size) is in kilobytes; convert to bytes.
ps -eo pid,comm,pcpu,pmem,rss --sort=-pcpu | head -n 21 | awk 'NR>1 {
  cpu=$3;
  rss_kb=$5;
  mem_bytes=rss_kb * 1024;
  printf "%s{\"pid\":%d,\"name\":\"%s\",\"cpu_pct\":%s,\"mem_bytes\":%d}", (NR>2?",":""), $1,$2,cpu,mem_bytes
}' | sed '1s/^/[/' | sed '$s/$/]/'


