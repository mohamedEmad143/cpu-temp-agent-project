#!/usr/bin/env bash
set -euo pipefail

# Disk SMART health using smartctl (smartmontools required)
# Outputs JSON array: [ {"filesystem":"/dev/sda","health":"PASSED"}, ... ]

if ! command -v smartctl >/dev/null 2>&1; then
  # smartctl not installed or not in PATH
  echo "[]"
  exit 0
fi

# Collect all block devices that appear in df output (filesystems)
mapfile -t filesystems < <(df -P | awk 'NR>1 {print $1}' | sort -u)

first=true
printf "["
for fs in "${filesystems[@]}"; do
  # Only run smartctl on real devices (skip tmpfs, overlay, etc.)
  if [[ "$fs" != /dev/* ]]; then
    continue
  fi

  # Run smartctl -H; may require root, so ignore failures and mark as UNKNOWN.
  health="$(smartctl -H "$fs" 2>/dev/null | awk -F: '/SMART overall-health/ {gsub(/^[ \t]+/,"",$2); print $2}')"
  if [[ -z "$health" ]]; then
    health="UNKNOWN"
  fi

  if [ "$first" = true ]; then
    first=false
  else
    printf ","
  fi

  printf '{"filesystem":"%s","health":"%s"}' "$fs" "$health"
done
printf "]"

#!/usr/bin/env bash
set -euo pipefail

# Disk SMART health using smartctl (smartmontools required)
# Outputs JSON array: [ {"filesystem":"/dev/sda1","health":"PASSED"}, ... ]

if ! command -v smartctl >/dev/null 2>&1; then
  # smartctl not installed or not in PATH
  echo "[]" 
  exit 0
fi

# Collect all block devices that appear in df output (filesystems)
mapfile -t filesystems < <(df -P | awk 'NR>1 {print $1}' | sort -u)

first=true
printf "["
for fs in "${filesystems[@]}"; do
  # Only run smartctl on real devices (skip tmpfs, overlay, etc.)
  if [[ "$fs" != /dev/* ]]; then
    continue
  fi

  # Run smartctl -H; may require root, so ignore failures and mark as UNKNOWN.
  health="$(smartctl -H "$fs" 2>/dev/null | awk -F: '/SMART overall-health/ {gsub(/^[ \t]+/,"",$2); print $2}')"
  if [[ -z "$health" ]]; then
    health="UNKNOWN"
  fi

  if [ "$first" = true ]; then
    first=false
  else
    printf ","
  </analysis to=functions.apply_patch  gemeentebestuur  TestingOther>

