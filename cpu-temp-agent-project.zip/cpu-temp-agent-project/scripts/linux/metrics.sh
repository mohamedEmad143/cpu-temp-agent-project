#!/usr/bin/env bash
set -euo pipefail

# CPU utilization (total + per-core) using /proc/stat with delta sampling
read_all_cpu() {
  grep '^cpu' /proc/stat
}

calc_usage_from_lines() {
  # $1: first line, $2: second line
  # shellcheck disable=SC2206
  local arr1=($1)
  # shellcheck disable=SC2206
  local arr2=($2)

  local idle1=${arr1[4]}
  local idle2=${arr2[4]}

  local total1=0
  local total2=0
  local i
  for i in "${arr1[@]:1}"; do total1=$((total1 + i)); done
  for i in "${arr2[@]:1}"; do total2=$((total2 + i)); done

  local diff_idle=$((idle2 - idle1))
  local diff_total=$((total2 - total1))

  if [ "$diff_total" -le 0 ]; then
    printf "0.0"
  else
    awk -v di="$diff_idle" -v dt="$diff_total" 'BEGIN { printf "%.1f", (1 - di/dt) * 100 }'
  fi
}

mapfile -t cpu_before < <(read_all_cpu)
sleep 0.5
mapfile -t cpu_after < <(read_all_cpu)

# Total CPU (first line)
cpu_total_usage=$(calc_usage_from_lines "${cpu_before[0]}" "${cpu_after[0]}")

# Per-core lines start from index 1 (cpu0, cpu1, ...)
cpu_cores_json=""
for ((i = 1; i < ${#cpu_before[@]}; i++)); do
  usage=$(calc_usage_from_lines "${cpu_before[$i]}" "${cpu_after[$i]}")
  if [ "$i" -gt 1 ]; then
    cpu_cores_json+=","
  fi
  cpu_cores_json+="$usage"
done

# Memory usage from /proc/meminfo (kB)
mem_total_kb=$(grep -i '^MemTotal:' /proc/meminfo | awk '{print $2}')
mem_available_kb=$(grep -i '^MemAvailable:' /proc/meminfo | awk '{print $2}')
mem_used_kb=$((mem_total_kb - mem_available_kb))

# Disk usage using df (bytes)
disk_json=$(df -B1 --output=source,size,used,avail,target -x tmpfs -x devtmpfs | awk 'NR>1 { printf "%s{\"filesystem\":\"%s\",\"size\":%s,\"used\":%s,\"available\":%s,\"mount\":\"%s\"}", (NR>2?",":""), $1,$2,$3,$4,$5 } END { }')

# Network usage from /proc/net/dev (bytes, not rates)
net_json=$(awk -F'[: ]+' 'NR>2 { iface=$1; rx=$3; tx=$11; if (NR>3) printf ","; printf "{\"iface\":\"" iface "\",\"rx_bytes\":%s,\"tx_bytes\":%s}", rx, tx }' /proc/net/dev)

printf '{'
printf '"platform":"linux",'
printf '"cpu":{"total_usage":%s,"cores":[%s]},' "$cpu_total_usage" "$cpu_cores_json"
printf '"memory":{"total_kb":%s,"used_kb":%s,"available_kb":%s},' "$mem_total_kb" "$mem_used_kb" "$mem_available_kb"
printf '"disks":[%s],' "$disk_json"
printf '"network":[%s]' "$net_json"
printf '}'


