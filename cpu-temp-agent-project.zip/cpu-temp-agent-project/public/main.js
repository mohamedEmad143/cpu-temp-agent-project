// --- DOM ELEMENT SELECTION ---
// This section grabs references to all the HTML elements that will be dynamically updated.
// Having them all in one place makes the code easier to manage.
const wsStatusEl = document.getElementById("ws-status");
const cpuUsageEl = document.getElementById("cpu-usage");
const cpuTempEl = document.getElementById("cpu-temp");
const memUsedEl = document.getElementById("mem-used");
const memTotalEl = document.getElementById("mem-total");
const netListEl = document.getElementById("net-list");
const diskListEl = document.getElementById("disk-list");
const procTbodyEl = document.getElementById("proc-tbody");
const procTableEl = document.getElementById("proc-table");
const gpuUsageEl = document.getElementById("gpu-usage");
const gpuTempEl = document.getElementById("gpu-temp");
const osLabelEl = document.getElementById("os-label");
const dockerLabelEl = document.getElementById("docker-label");
const updateSpeedSelect = document.getElementById("update-speed");
const toggleDark = document.getElementById("toggle-dark");
const panelToggles = document.querySelectorAll("[data-panel-toggle]");

// Elements for the summary panel at the top.
const summaryCpuEl = document.getElementById("summary-cpu");
const summaryRamEl = document.getElementById("summary-ram");
const summaryGpuEl = document.getElementById("summary-gpu");
const summaryDiskEl = document.getElementById("summary-disk");

const cpuCtx = document.getElementById("cpu-chart").getContext("2d");
const memCtx = document.getElementById("mem-chart").getContext("2d");
const gpuCtx = document.getElementById("gpu-chart")?.getContext("2d");

const MAX_POINTS = 60;
let minUpdateIntervalMs = parseInt(updateSpeedSelect?.value ?? "2000", 10) || 2000;
let lastUpdateTime = 0;
let procSortKey = "cpu_pct";
let procSortDir = "desc";

const cpuChart = new Chart(cpuCtx, {
  type: "line",
  data: {
    labels: [],
    datasets: [
      {
        label: "CPU Usage %",
        data: [],
        borderColor: "#38bdf8",
        backgroundColor: "rgba(56, 189, 248, 0.15)",
        tension: 0.3,
        fill: true,
        borderWidth: 2,
        pointRadius: 0,
      },
    ],
  },
  options: {
    animation: false,
    responsive: true,
    scales: {
      x: { display: false },
      y: { beginAtZero: true, max: 100 },
    },
    plugins: {
      legend: { display: false },
    },
  },
});

const memChart = new Chart(memCtx, {
  type: "line",
  data: {
    labels: [],
    datasets: [
      {
        label: "Memory Used (GB)",
        data: [],
        borderColor: "#a855f7",
        backgroundColor: "rgba(168, 85, 247, 0.15)",
        tension: 0.3,
        fill: true,
        borderWidth: 2,
        pointRadius: 0,
      },
    ],
  },
  options: {
    animation: false,
    responsive: true,
    scales: {
      x: { display: false },
      y: { beginAtZero: true },
    },
    plugins: {
      legend: { display: false },
    },
  },
});

// The GPU chart is optional because the panel might be hidden or data unavailable.
const gpuChart = gpuCtx
  ? new Chart(gpuCtx, {
      type: "line",
      data: {
        labels: [],
        datasets: [
          {
            label: "GPU Usage %",
            data: [],
            borderColor: "#f97316",
            backgroundColor: "rgba(249, 115, 22, 0.15)",
            tension: 0.3,
            fill: true,
            borderWidth: 2,
            pointRadius: 0,
          },
        ],
      },
      options: {
        animation: false,
        responsive: true,
        scales: {
          x: { display: false },
          y: { beginAtZero: true, max: 100 },
        },
        plugins: {
          legend: { display: false },
        },
      },
    })
  : null;

/**
 * Updates the WebSocket status indicator in the top bar.
 * @param {boolean} connected - True if the WebSocket is connected, false otherwise.
 */
function setWsStatus(connected) {
  wsStatusEl.textContent = connected ? "WebSocket: Connected" : "WebSocket: Disconnected";
  wsStatusEl.classList.toggle("ws-status-connected", connected);
  wsStatusEl.classList.toggle("ws-status-disconnected", !connected);
}

/**
 * Converts a number of bytes into a human-readable string (e.g., KB, MB, GB).
 * @param {number} bytes - The number of bytes.
 */
function humanBytes(bytes) {
  if (!Number.isFinite(bytes)) return "-";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  let v = bytes;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(1)} ${units[i]}`;
}

/**
 * Updates static information in the UI based on the first metrics payload (e.g., OS, Docker status).
 * @param {object} metrics - The full metrics object from the server.
 */
function applySettingsFromMetrics(metrics) {
  if (metrics.platform && osLabelEl) {
    osLabelEl.textContent = `OS: ${metrics.platform}`;
  }
  if (typeof metrics.dockerRunning === "boolean" && dockerLabelEl) {
    dockerLabelEl.textContent = metrics.dockerRunning ? "Docker: Running" : "Docker: Not running";
  }
}

/**
 * This is the main function for updating the UI. It's called every time a new 'metrics'
 * message is received from the WebSocket server. It updates all KPIs, charts, and tables.
 * @param {object} metrics - The full metrics object from the server.
 */
function handleMetrics(metrics) {
  // Throttle UI updates based on the user's selected update speed to prevent overwhelming the browser.
  const now = Date.now();
  if (now - lastUpdateTime < minUpdateIntervalMs) {
    return;
  }
  lastUpdateTime = now;

  applySettingsFromMetrics(metrics); // Update one-time info like OS.

  // --- CPU METRICS ---
  const cpuUsage = metrics.cpu?.total_usage ?? null;
  if (cpuUsage !== null && cpuUsage !== undefined) {
    const cpuText = `${cpuUsage.toFixed(1)} %`;
    cpuUsageEl.textContent = cpuText;
    if (summaryCpuEl) summaryCpuEl.textContent = cpuText;

    const label = new Date(metrics.timestamp).toLocaleTimeString();
    // Add new data to the chart and remove the oldest point if the max is reached.
    cpuChart.data.labels.push(label);
    cpuChart.data.datasets[0].data.push(cpuUsage);
    if (cpuChart.data.labels.length > MAX_POINTS) {
      cpuChart.data.labels.shift();
      cpuChart.data.datasets[0].data.shift();
    }
    cpuChart.update("none");
  }

  const cpuTemp = metrics.temperatures?.cpu ?? null;
  cpuTempEl.textContent =
    cpuTemp !== null && cpuTemp !== undefined ? `${cpuTemp} °C` : "- °C";

  // --- GPU METRICS --- (uses the first GPU found as the primary one)
  const gpus = metrics.gpus || [];
  const gpu0 = Array.isArray(gpus) && gpus.length > 0 ? gpus[0] : null;
  if (gpu0) {
    const usage = gpu0.utilization ?? null;
    const temp = gpu0.temp_c ?? metrics.temperatures?.gpu ?? null;
    const memUsedMb = gpu0.mem_used_mb ?? null;
    const memTotalMb = gpu0.mem_total_mb ?? null;

    if (gpuUsageEl && usage !== null && usage !== undefined) {
      const clamped = Math.max(0, Math.min(usage, 100));
      const gpuText = `${clamped.toFixed(1)} %`;
      gpuUsageEl.textContent = gpuText;
      if (summaryGpuEl) summaryGpuEl.textContent = gpuText;

      if (gpuChart) {
        // Add new data to the GPU chart.
        const label = new Date(metrics.timestamp).toLocaleTimeString();
        gpuChart.data.labels.push(label);
        gpuChart.data.datasets[0].data.push(clamped);
        if (gpuChart.data.labels.length > MAX_POINTS) {
          gpuChart.data.labels.shift();
          gpuChart.data.datasets[0].data.shift();
        }
        gpuChart.update("none");
      }
    }

    if (gpuTempEl) {
      let text =
        temp !== null && temp !== undefined ? `${Math.round(temp)} °C` : "- °C";
      if (memUsedMb !== null && memUsedMb !== undefined && memTotalMb !== null && memTotalMb !== undefined) {
        const usedGb = memUsedMb / 1024;
        const totalGb = memTotalMb / 1024;
        text += ` • ${usedGb.toFixed(1)}/${totalGb.toFixed(1)} GB`;
      }
      gpuTempEl.textContent = text;
    }
  } else {
    if (gpuUsageEl) gpuUsageEl.textContent = "- %";
    if (gpuTempEl) gpuTempEl.textContent = "- °C";
  }

  // --- PER-CORE CPU BARS ---
  const cores = metrics.cpu?.cores || [];
  const coresContainer = document.getElementById("cpu-cores");
  if (coresContainer) {
    coresContainer.innerHTML = "";
    cores.forEach((val, idx) => {
      const clamped = Math.max(0, Math.min(val ?? 0, 100));
      const bar = document.createElement("div");
      bar.className = "core-bar";
      const fill = document.createElement("div");
      fill.className = "core-bar-fill";
      fill.style.width = `${clamped}%`;
      bar.appendChild(fill);
      coresContainer.appendChild(bar);
    });
  }

  // --- MEMORY METRICS ---
  const mem = metrics.memory;
  if (mem) {
    const totalBytes = (mem.total_kb ?? 0) * 1024;
    const usedBytes = (mem.used_kb ?? 0) * 1024;
    memTotalEl.textContent = humanBytes(totalBytes);
    memUsedEl.textContent = humanBytes(usedBytes);

    if (summaryRamEl && totalBytes > 0) {
      const ramPct = (usedBytes / totalBytes) * 100;
      summaryRamEl.textContent = `${ramPct.toFixed(1)} %`;
    }

    const label = new Date(metrics.timestamp).toLocaleTimeString();
    // Add new data to the memory chart (in GB).
    const usedGB = usedBytes / (1024 * 1024 * 1024);
    memChart.data.labels.push(label);
    memChart.data.datasets[0].data.push(usedGB);
    if (memChart.data.labels.length > MAX_POINTS) {
      memChart.data.labels.shift();
      memChart.data.datasets[0].data.shift();
    }
    memChart.update("none");
  }

  // --- DISK METRICS ---
  const disks = metrics.disks || [];
  if (diskListEl) {
    const lines = (disks || []).map((d) => {
      const usedPct = d.size > 0 ? ((d.used / d.size) * 100).toFixed(1) : "-";
      const label = d.mount || d.filesystem || "";
      const health = d.health;
      let healthText = "";
      // Determine the text and color for the health status pill.
      let healthClass = "pill-unknown";
      if (typeof health === "string") {
        const h = health.toUpperCase();
        if (h.includes("PASS")) {
          healthText = "OK";
          healthClass = "pill-ok";
        } else if (h.includes("FAIL") || h.includes("BAD")) {
          healthText = "FAIL";
          healthClass = "pill-bad";
        } else {
          healthText = health;
          healthClass = "pill-unknown";
        }
      }
      const healthSpan =
        healthText !== ""
          ? ` <span class="pill ${healthClass}">${healthText}</span>`
          : "";
      return `${label}: ${humanBytes(d.used)}/${humanBytes(d.size)} (${usedPct}%)${healthSpan}`;
    });

    diskListEl.innerHTML = lines.join("<br>") || "No disk data";
  }

  // --- NETWORK METRICS ---
  const nets = metrics.network || [];
  netListEl.textContent =
    nets
      .map((n) => `${n.iface}: RX ${humanBytes(n.rx_bytes)} | TX ${humanBytes(n.tx_bytes)}`)
      .join("\n") || "No network data";

  // --- PROCESSES TABLE ---
  const procs = metrics.processes || [];
  if (procTbodyEl && Array.isArray(procs)) {
    const sorted = [...procs].sort((a, b) => {
      const av = a[procSortKey];
      const bv = b[procSortKey];
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      if (typeof av === "string") {
        return procSortDir === "asc" ? String(av).localeCompare(bv) : String(bv).localeCompare(av);
      }
      return procSortDir === "asc" ? av - bv : bv - av;
    });

    procTbodyEl.innerHTML = "";
    sorted.forEach((p) => {
      const tr = document.createElement("tr");
      const cpu = Math.max(0, Math.min(p.cpu_pct ?? 0, 100));
      const memBytes = p.mem_bytes ?? 0;

      tr.innerHTML = `
        <td>${p.name ?? ""}</td>
        <td class="numeric">${p.pid ?? ""}</td>
        <td class="numeric">${cpu.toFixed(1)}%</td>
        <td class="numeric">${humanBytes(memBytes)}</td>
      `;
      procTbodyEl.appendChild(tr);
    });
  }

  // --- SUMMARY DISK USAGE --- (finds the disk with the highest percentage usage)
  if (summaryDiskEl) {
    let maxPct = null;
    for (const d of disks) {
      if (!d || d.size <= 0) continue;
      const pct = (d.used / d.size) * 100;
      if (Number.isFinite(pct)) {
        if (maxPct === null || pct > maxPct) {
          maxPct = pct;
        }
      }
    }
    summaryDiskEl.textContent =
      maxPct !== null ? `${maxPct.toFixed(1)} %` : "- %";
  }
}

/**
 * Loads user settings from `localStorage` on page load.
 * This includes update speed, dark mode, and which panels are visible.
 */
function loadUserSettings() {
  if (!updateSpeedSelect) return;

  const storedSpeed = window.localStorage.getItem("updateSpeedMs");
  if (storedSpeed) {
    updateSpeedSelect.value = storedSpeed;
    minUpdateIntervalMs = parseInt(storedSpeed, 10) || minUpdateIntervalMs;
  }

  if (toggleDark) {
    const storedDark = window.localStorage.getItem("darkMode");
    if (storedDark === "false") {
      toggleDark.checked = false;
      document.body.classList.add("light");
    }
  }

  const storedPanels = window.localStorage.getItem("visiblePanels");
  if (storedPanels) {
    const visible = JSON.parse(storedPanels);
    panelToggles.forEach((input) => {
      const key = input.getAttribute("data-panel-toggle");
      const isVisible = visible[key] ?? true;
      input.checked = isVisible;
      const panel = document.querySelector(`[data-panel="${key}"]`);
      if (panel) {
        panel.style.display = isVisible ? "" : "none";
      }
    });
  }
}

/**
 * Initializes all the UI event listeners for the settings panel.
 * Saves any changes to `localStorage`.
 */
function initSettingsUi() {
  if (updateSpeedSelect) {
    updateSpeedSelect.addEventListener("change", () => {
      minUpdateIntervalMs = parseInt(updateSpeedSelect.value, 10) || minUpdateIntervalMs;
      window.localStorage.setItem("updateSpeedMs", String(minUpdateIntervalMs));
    });
  }

  if (toggleDark) {
    toggleDark.addEventListener("change", () => {
      const isDark = toggleDark.checked;
      document.body.classList.toggle("light", !isDark);
      window.localStorage.setItem("darkMode", isDark ? "true" : "false");
    });
  }

  panelToggles.forEach((input) => {
    input.addEventListener("change", () => {
      const key = input.getAttribute("data-panel-toggle");
      const panel = document.querySelector(`[data-panel="${key}"]`);
      if (panel) {
        panel.style.display = input.checked ? "" : "none";
      }
      const current = JSON.parse(window.localStorage.getItem("visiblePanels") || "{}");
      current[key] = input.checked;
      window.localStorage.setItem("visiblePanels", JSON.stringify(current));
    });
  });
}

/**
 * Initializes the click event listeners on the process table headers for sorting.
 */
function initProcessTableSorting() {
  if (!procTableEl) return;
  const headers = procTableEl.querySelectorAll("th[data-sort-key]");
  headers.forEach((th) => {
    th.addEventListener("click", () => {
      const key = th.getAttribute("data-sort-key");
      if (!key) return;
      if (procSortKey === key) {
        procSortDir = procSortDir === "asc" ? "desc" : "asc";
      } else {
        procSortKey = key;
        procSortDir = key === "name" ? "asc" : "desc";
      }
    });
  });
}

/**
 * Establishes a WebSocket connection to the backend server.
 * It handles opening, closing, and receiving messages.
 * If the connection is lost, it automatically tries to reconnect after 2 seconds.
 */
function connectWs() {
  const loc = window.location;
  const proto = loc.protocol === "https:" ? "wss:" : "ws:";
  const wsUrl = `${proto}//${loc.host}/ws`;

  const ws = new WebSocket(wsUrl);

  ws.onopen = () => setWsStatus(true);
  ws.onclose = () => {
    // When the connection closes, update the status and schedule a reconnect.
    setWsStatus(false);
    setTimeout(connectWs, 2000);
  };
  ws.onerror = () => {
    ws.close();
  };
  ws.onmessage = (event) => {
    try {
      // When a message is received, parse it and pass the data to the UI handler.
      const msg = JSON.parse(event.data);
      if (msg.type === "metrics" && msg.data) {
        handleMetrics(msg.data);
      }
    } catch (e) {
      console.error("Failed to parse WS message", e);
    }
  };
}

// --- INITIALIZATION ---
loadUserSettings();
initSettingsUi();
initProcessTableSorting();
connectWs();
