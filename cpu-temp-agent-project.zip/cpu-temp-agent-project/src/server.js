import http from "http";
import express from "express";
import { WebSocketServer } from "ws";
import { execFile } from "child_process";
import { promisify } from "util";
import os from "os";
import fs from "fs";
import path from "path";
import url from "url";
import PDFDocument from "pdfkit";

// --- SETUP & CONFIGURATION ---
// ES module equivalent of __dirname to get the current directory path.
const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
// Promisify execFile to use it with async/await for cleaner code when running scripts.
const execFileAsync = promisify(execFile);

// Initialize Express app, HTTP server, and WebSocket server.
const app = express();
const server = http.createServer(app);
// The WebSocket server is available at the `/ws` path. The frontend will connect to this.
const wss = new WebSocketServer({ server, path: "/ws" });

// --- CONSTANTS ---
const METRICS_INTERVAL_MS = 2000;
const HISTORY_DIR = path.join(__dirname, "..", "history");
const HISTORY_FILE = path.join(HISTORY_DIR, "metrics.jsonl");

// --- STATE VARIABLES ---
// Simple caching for the Docker status check to avoid running the command too frequently.
let lastDockerCheck = 0;
let lastDockerRunning = null;

// Ensure the directory for storing historical metrics exists.
if (!fs.existsSync(HISTORY_DIR)) {
  fs.mkdirSync(HISTORY_DIR, { recursive: true });
}

// Serve all static files (index.html, main.js, styles.css) from the 'public' directory.
app.use(express.static(path.join(__dirname, "..", "public")));

// --- API ENDPOINTS ---

// Endpoint to get the latest collected metrics as a single JSON object.
app.get("/metrics", async (_req, res) => {
  try {
    const metrics = await collectMetrics();
    res.json(metrics);
  } catch (err) {
    console.error("Error in /metrics:", err);
    res.status(500).json({ error: "failed_to_collect_metrics" });
  }
});

// Endpoint to get all historical metrics stored in the .jsonl file.
app.get("/metrics-history", (_req, res) => {
  if (!fs.existsSync(HISTORY_FILE)) {
    return res.json([]);
  }
  const lines = fs.readFileSync(HISTORY_FILE, "utf8").trim().split("\n");
  const records = lines
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      try {
        return JSON.parse(l);
      } catch {
        return null;
      }
    })
    .filter((x) => x !== null);
  res.json(records);
});

// Endpoint to export historical data in various formats (jsonl, csv, txt, html, pdf).
app.get("/export/:format", (req, res) => {
  const { format } = req.params;
  if (!fs.existsSync(HISTORY_FILE)) {
    return res.status(404).send("No history available");
  }

  const lines = fs.readFileSync(HISTORY_FILE, "utf8").trim().split("\n");
  const records = lines
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      try {
        return JSON.parse(l);
      } catch {
        return null;
      }
    })
    .filter((x) => x !== null);

  switch (format) {
    case "jsonl":
      res.setHeader("Content-Type", "application/jsonl");
      res.setHeader("Content-Disposition", 'attachment; filename=\"metrics.jsonl\"');
      return res.send(lines.join("\n"));
    case "csv":
      exportCsv(records, res);
      break;
    case "txt":
      exportTxt(records, res);
      break;
    case "html":
      exportHtml(records, res);
      break;
    case "pdf":
      exportPdf(records, res);
      break;
    default:
      res.status(400).send("Unsupported format. Use csv, txt, html, pdf, or jsonl.");
  }
});

// --- DATA COLLECTION FUNCTIONS ---

/**
 * Fetches hardware temperatures and utilization from the C# agent (Windows only).
 * This function communicates with the `CpuTempAgent.exe` process over HTTP.
 */
async function callCpuTempAgent() {
  if (process.platform !== "win32") {
    return {
      cpu_temp: null,
      cpu_utilization: null,
      gpu_utilization: null,
      gpu_temp: null,
    };
  }

  // The C# agent runs a local server on port 8085.
  const resp = await fetch("http://localhost:8085/cpu-temp").catch(() => null);
  if (!resp || !resp.ok) {
    return {
      cpu_temp: null,
      cpu_utilization: null,
      gpu_utilization: null,
      gpu_temp: null,
    };
  }

  try {
    const data = await resp.json();
    return {
      cpu_temp: data.cpu_temp ?? null,
      cpu_utilization: data.cpu_utilization ?? null,
      gpu_utilization: data.gpu_utilization ?? null,
      gpu_temp: data.gpu_temp ?? null,
    };
  } catch {
    return {
      cpu_temp: null,
      cpu_utilization: null,
      gpu_utilization: null,
      gpu_temp: null,
    };
  }
}

/**
 * Checks if the Docker daemon is running.
 * Includes a simple 10-second cache to avoid excessive checks.
 */
async function getDockerStatus() {
  const now = Date.now();
  if (now - lastDockerCheck < 10000 && lastDockerRunning !== null) {
    return lastDockerRunning;
  }

  try {
    await execFileAsync("docker", ["info"], { timeout: 2000 });
    lastDockerRunning = true;
  } catch {
    lastDockerRunning = false;
  }

  lastDockerCheck = now;
  return lastDockerRunning;
}

/**
 * Runs platform-specific scripts to gather system metrics.
 * It detects the OS (Linux/Windows) and executes the corresponding shell/PowerShell scripts.
 * The scripts output data in JSON format, which is parsed here.
 */
async function runMetricsScript() {
  const platform = process.platform;

  if (platform === "linux") { // --- LINUX METRICS ---
    const metricsScript = path.join(__dirname, "..", "scripts", "linux", "metrics.sh");
    const processesScript = path.join(__dirname, "..", "scripts", "linux", "processes.sh");
    const gpuScript = path.join(__dirname, "..", "scripts", "linux", "gpu.sh");
    const diskSmartScript = path.join(__dirname, "..", "scripts", "linux", "disk_smart.sh");

    const [metricsOut, processesOut, gpuOut, diskSmartOut] = await Promise.all([
      execFileAsync("bash", [metricsScript], { timeout: 5000 }),
      execFileAsync("bash", [processesScript], { timeout: 5000 }),
      execFileAsync("bash", [gpuScript], { timeout: 5000 }).catch(() => ({ stdout: "{\"gpus\":[]}" })),
      execFileAsync("bash", [diskSmartScript], { timeout: 5000 }).catch(() => ({ stdout: "[]" })),
    ]);

    // Parse the JSON output from each script and combine them.
    const base = JSON.parse(metricsOut.stdout);
    const processes = JSON.parse(processesOut.stdout);
    const gpuData = JSON.parse(gpuOut.stdout || "{\"gpus\":[]}");
    const diskHealth = JSON.parse(diskSmartOut.stdout || "[]");
    base.processes = processes;
    if (Array.isArray(gpuData.gpus)) {
      base.gpus = gpuData.gpus;
    }
    // Merge disk health status into the main disk info.
    if (Array.isArray(base.disks) && Array.isArray(diskHealth)) {
      for (const d of base.disks) {
        const h = diskHealth.find((x) => x.filesystem === d.filesystem);
        if (h && typeof h.health === "string") {
          d.health = h.health;
        }
      }
    }
    return base;
  }

  if (platform === "win32") { // --- WINDOWS METRICS ---
    // Prefer WSL + bash if available for Linux-style metrics
    const linuxScript = path.join("/mnt", "c", "cpu-temp-agent", "scripts", "linux", "metrics.sh");
    try {
      const { stdout } = await execFileAsync("wsl", ["bash", linuxScript], { timeout: 5000 });
      return JSON.parse(stdout);
    } catch (e) {
      console.warn("WSL metrics failed, falling back to PowerShell metrics:", e.message);
    }

    // If WSL fails or is not available, use the native PowerShell scripts.
    const psMetricsScript = path.join(__dirname, "..", "scripts", "windows", "metrics.ps1");
    const psProcessesScript = path.join(__dirname, "..", "scripts", "windows", "processes.ps1");
    const psGpuScript = path.join(__dirname, "..", "scripts", "windows", "gpu.ps1");
    const psDiskSmartScript = path.join(__dirname, "..", "scripts", "windows", "disk_smart.ps1");

    const [metricsOut, processesOut, gpuOut, diskSmartOut] = await Promise.all([
      execFileAsync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", psMetricsScript], {
        timeout: 5000,
      }),
      execFileAsync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", psProcessesScript], {
        timeout: 5000,
      }),
      execFileAsync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", psGpuScript], {
        timeout: 5000,
      }).catch(() => ({ stdout: "{\"gpus\":[]}" })),
      execFileAsync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", psDiskSmartScript], {
        timeout: 5000,
      }).catch(() => ({ stdout: "[]" })),
    ]);

    // Parse and combine the JSON output from the PowerShell scripts.
    const base = JSON.parse(metricsOut.stdout);
    const processes = JSON.parse(processesOut.stdout);
    const gpuData = JSON.parse(gpuOut.stdout || "{\"gpus\":[]}");
    const diskHealth = JSON.parse(diskSmartOut.stdout || "[]");
    base.processes = processes;
    if (Array.isArray(gpuData.gpus)) {
      base.gpus = gpuData.gpus;
    }
    // Merge disk health status into the main disk info.
    if (Array.isArray(base.disks) && Array.isArray(diskHealth)) {
      for (const d of base.disks) {
        const h = diskHealth.find((x) => x.filesystem === d.filesystem || x.device === d.mount || x.device === d.filesystem);
        if (h && typeof h.health === "string") {
          d.health = h.health;
        }
      }
    }
    return base;
  }

  // --- FALLBACK METRICS --- for unsupported platforms like macOS.
  const load = os.loadavg();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  return {
    platform,
    cpu: { load1: load[0], load5: load[1], load15: load[2] },
    memory: { total: totalMem, free: freeMem, used: totalMem - freeMem },
    disks: [],
    network: [],
  };
}

/**
 * The main orchestrator function for collecting all metrics.
 * It calls the script runner, the C# agent fetcher, and the Docker status checker in parallel.
 * It then merges all the data into a single, unified `metrics` object.
 */
async function collectMetrics() {
  const [baseMetrics, temp, dockerRunning] = await Promise.all([ // Run all data collection in parallel for speed.
    runMetricsScript(),
    callCpuTempAgent(),
    getDockerStatus(),
  ]);
  const timestamp = new Date().toISOString();
  const metrics = {
    timestamp,
    ...baseMetrics,
    dockerRunning,
    gpus: Array.isArray(baseMetrics.gpus) ? baseMetrics.gpus : [],
  };

  // Merge data from the C# agent. The C# agent's data is preferred for utilization because it's more accurate.
  metrics.cpu = metrics.cpu || {};
  if (temp.cpu_utilization != null) {
    metrics.cpu.total_usage = temp.cpu_utilization;
  } else if (metrics.cpu.total_usage == null && baseMetrics.cpu?.total_usage != null) {
    metrics.cpu.total_usage = baseMetrics.cpu.total_usage;
  }

  // Merge GPU data, again prioritizing the C# agent's data.
  metrics.gpus = Array.isArray(metrics.gpus) ? metrics.gpus : [];
  if (metrics.gpus.length === 0) {
    metrics.gpus.push({});
  }
  if (temp.gpu_utilization != null) {
    metrics.gpus[0].utilization = temp.gpu_utilization;
  } else if (metrics.gpus[0].utilization == null && Array.isArray(baseMetrics.gpus) && baseMetrics.gpus.length > 0) {
    metrics.gpus[0].utilization = baseMetrics.gpus[0].utilization ?? null;
  }

  // Add temperature data from the C# agent.
  metrics.temperatures = {
    cpu: temp.cpu_temp ?? null,
    gpu: temp.gpu_temp ?? null,
  };

  // Asynchronously append the latest metrics to the history file.
  fs.appendFile(HISTORY_FILE, JSON.stringify(metrics) + "\n", (err) => { // .jsonl format (one JSON object per line)
    if (err) console.error("Failed to append metrics history:", err);
  });

  return metrics;
}

function exportCsv(records, res) {
  /**
   * Converts an array of metric records into a CSV string and sends it as a downloadable file.
   * @param {Array<Object>} records - The metric records.
   * @param {express.Response} res - The Express response object.
   */
  const header = [
    "timestamp",
    "platform",
    "cpu_usage",
    "cpu_temp",
    "mem_total_kb",
    "mem_used_kb",
    "mem_available_kb",
  ];
  const rows = [header.join(",")];

  for (const r of records) {
    const row = [
      r.timestamp ?? "",
      r.platform ?? "",
      r.cpu?.usage ?? "",
      r.temperatures?.cpu ?? "",
      r.memory?.total_kb ?? "",
      r.memory?.used_kb ?? "",
      r.memory?.available_kb ?? "",
    ];
    rows.push(row.join(","));
  }

  const csv = rows.join("\n");
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", 'attachment; filename=\"metrics.csv\"');
  res.send(csv);
}

function exportTxt(records, res) {
  /**
   * Converts records to a simple plain text format.
   * @param {Array<Object>} records - The metric records.
   * @param {express.Response} res - The Express response object.
   */
  const lines = records.map(
    (r) =>
      `${r.timestamp} platform=${r.platform} cpu=${r.cpu?.usage ?? "?"}% temp=${r.temperatures?.cpu ?? "?"}C mem_used=${
        r.memory?.used_kb ?? "?"
      }kB`
  );
  const txt = lines.join("\n");
  res.setHeader("Content-Type", "text/plain");
  res.setHeader("Content-Disposition", 'attachment; filename=\"metrics.txt\"');
  res.send(txt);
}

function exportHtml(records, res) {
  /**
   * Converts records to an HTML table for easy viewing in a browser.
   * @param {Array<Object>} records - The metric records.
   * @param {express.Response} res - The Express response object.
   */
  const rows = records
    .map(
      (r) => `<tr>
  <td>${r.timestamp ?? ""}</td>
  <td>${r.platform ?? ""}</td>
  <td>${r.cpu?.usage ?? ""}</td>
  <td>${r.temperatures?.cpu ?? ""}</td>
  <td>${r.memory?.used_kb ?? ""}</td>
</tr>`
    )
    .join("\n");

  const html = `<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"UTF-8\" />
    <title>Metrics Export</title>
    <style>
      body { font-family: system-ui, sans-serif; padding: 1rem; }
      table { border-collapse: collapse; width: 100%; }
      th, td { border: 1px solid #ccc; padding: 4px 6px; font-size: 12px; }
      th { background: #f3f4f6; }
    </style>
  </head>
  <body>
    <h1>System Metrics</h1>
    <table>
      <thead>
        <tr>
          <th>Timestamp</th>
          <th>Platform</th>
          <th>CPU Usage %</th>
          <th>CPU Temp °C</th>
          <th>Mem Used (kB)</th>
        </tr>
      </thead>
      <tbody>
${rows}
      </tbody>
    </table>
  </body>
</html>`;

  res.setHeader("Content-Type", "text/html");
  res.setHeader("Content-Disposition", 'attachment; filename=\"metrics.html\"');
  res.send(html);
}

function exportPdf(records, res) {
  /**
   * Converts records to a PDF document.
   * @param {Array<Object>} records - The metric records.
   * @param {express.Response} res - The Express response object.
   */
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", 'attachment; filename=\"metrics.pdf\"');

  const doc = new PDFDocument({ margin: 40 });
  doc.pipe(res);

  doc.fontSize(18).text("System Metrics Report", { align: "left" });
  doc.moveDown();
  doc.fontSize(10);

  for (const r of records) {
    const line = `${r.timestamp ?? ""} | platform=${r.platform ?? ""} | cpu=${r.cpu?.usage ?? "?"}% | temp=${
      r.temperatures?.cpu ?? "?"
    }C | mem_used=${r.memory?.used_kb ?? "?"}kB`;
    doc.text(line);
  }

  doc.end();
}

// --- WEBSOCKET LOGIC ---
// This section handles real-time communication with the frontend dashboard.

const clients = new Set();

// When a new client connects, add them to the set of active clients.
wss.on("connection", (ws) => {
  clients.add(ws);
  ws.on("close", () => clients.delete(ws));
});

// This is the main broadcasting loop. Every `METRICS_INTERVAL_MS`, it collects fresh metrics.
setInterval(async () => {
  if (clients.size === 0) return;
  try {
    const metrics = await collectMetrics();
    const payload = JSON.stringify({ type: "metrics", data: metrics });
    for (const ws of clients) {
      if (ws.readyState === ws.OPEN) {
        ws.send(payload);
      }
    }
  } catch (err) {
    console.error("Error while collecting/broadcasting metrics:", err);
  }
}, METRICS_INTERVAL_MS);

// --- SERVER START ---
const PORT = process.env.PORT || 8090;
server.listen(PORT, () => {
  console.log(`System monitor backend listening on http://localhost:${PORT}`);
  console.log(`WebSocket endpoint: ws://localhost:${PORT}/ws`);
});
