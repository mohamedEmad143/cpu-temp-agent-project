using System.Net;
using System.Runtime.Versioning;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Linq;
using System.Diagnostics;
using System.Management; // WMI fallback
using LibreHardwareMonitor.Hardware;

[SupportedOSPlatform("windows")]
internal static class Program
{
    // آخر قراءات محفوظة في الذاكرة
    private static double? _cpuTemp;
    private static double? _gpuTemp;
    private static double? _cpuUtilization;
    private static double? _gpuUtilization;

    // Threshold للـ Alert
    private const double CPU_ALERT_TEMP = 80;

    public static async Task<int> Main()
    {
        // نتأكد إننا شغالين على Windows
        if (!OperatingSystem.IsWindows())
        {
            Console.Error.WriteLine("Windows only.");
            return 1;
        }

        // LibreHardwareMonitor محتاج Admin
        if (!IsAdministrator())
        {
            Console.Error.WriteLine("Run as Administrator.");
            return 1;
        }

        // الكائن الأساسي اللي بيقرأ الهاردوير
        var computer = new Computer
        {
            IsCpuEnabled = true,
            IsGpuEnabled = true,
            IsMotherboardEnabled = true
        };

        computer.Open(); // فتح الوصول للهاردوير

        // HTTP Server
        using var listener = new HttpListener();
        listener.Prefixes.Add("http://+:8085/");

        // Cancel عند Ctrl+C
        using var cts = new CancellationTokenSource();
        Console.CancelKeyPress += (_, e) =>
        {
            e.Cancel = true;
            cts.Cancel();
        };

        // Visitor لتحديث القراءات
        var updateVisitor = new UpdateVisitor();

        // Performance Counters للاستخدام
        PerformanceCounter? cpuCounter = null;
        PerformanceCounter[] gpuCounters = Array.Empty<PerformanceCounter>();

        try
        {
            cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
        }
        catch { }

        try
        {
            if (PerformanceCounterCategory.Exists("GPU Engine"))
            {
                var cat = new PerformanceCounterCategory("GPU Engine");
                gpuCounters = cat.GetInstanceNames()
                    .Select(n => new PerformanceCounter("GPU Engine", "Utilization Percentage", n))
                    .ToArray();
            }
        }
        catch
        {
            gpuCounters = Array.Empty<PerformanceCounter>();
        }

        // Background Loop لتحديث القيم
        _ = Task.Run(async () =>
        {
            while (!cts.IsCancellationRequested)
            {
                // قراءة الحرارة
                var (cpu, gpu) = ReadTemperatures(computer, updateVisitor);
                _cpuTemp = cpu;
                _gpuTemp = gpu;

                // 🔥 ALERT لو CPU سخن
                if (_cpuTemp.HasValue && _cpuTemp.Value >= CPU_ALERT_TEMP)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"⚠ ALERT: CPU Temperature = {_cpuTemp.Value:F1} °C");
                    Console.ResetColor();
                }

                // CPU Utilization
                try
                {
                    if (cpuCounter != null)
                        _cpuUtilization = cpuCounter.NextValue();
                }
                catch { }

                // GPU Utilization (average)
                try
                {
                    if (gpuCounters.Length > 0)
                    {
                        double sum = 0;
                        int count = 0;

                        foreach (var c in gpuCounters)
                        {
                            var v = c.NextValue();
                            if (!double.IsNaN(v))
                            {
                                sum += v;
                                count++;
                            }
                        }

                        if (count > 0)
                            _gpuUtilization = sum / count;
                    }
                }
                catch { }

                await Task.Delay(2000); // كل ثانيتين
            }
        });

        listener.Start();
        Console.WriteLine("✅ Agent running at http://localhost:8085/cpu-temp");

        // HTTP loop
        while (!cts.IsCancellationRequested)
        {
            var ctx = await listener.GetContextAsync();
            _ = Task.Run(() => HandleRequest(ctx));
        }

        computer.Close();
        return 0;
    }

    // معالجة HTTP Request
    private static async Task HandleRequest(HttpListenerContext context)
    {
        AddCors(context.Response);

        // Route بسيط
        if (context.Request.HttpMethod != "GET" ||
            context.Request.Url?.AbsolutePath != "/cpu-temp")
        {
            context.Response.StatusCode = 404;
            context.Response.Close();
            return;
        }

        // Response JSON
        var payload = new
        {
            cpu_temp = _cpuTemp.HasValue ? (int)Math.Round(_cpuTemp.Value) : (int?)null,
            cpu_utilization = _cpuUtilization.HasValue ? Math.Round(_cpuUtilization.Value, 1) : (double?)null,
            gpu_temp = _gpuTemp.HasValue ? (int)Math.Round(_gpuTemp.Value) : (int?)null,
            gpu_utilization = _gpuUtilization.HasValue ? Math.Round(_gpuUtilization.Value, 1) : (double?)null,
            cpu_temp_alert = _cpuTemp.HasValue && _cpuTemp.Value >= CPU_ALERT_TEMP
        };

        var json = JsonSerializer.Serialize(payload);
        var bytes = Encoding.UTF8.GetBytes(json);

        context.Response.ContentType = "application/json";
        await context.Response.OutputStream.WriteAsync(bytes);
        context.Response.Close();
    }

    // قراءة الحرارة من LibreHardwareMonitor + fallback
    private static (double? Cpu, double? Gpu) ReadTemperatures(Computer computer, UpdateVisitor visitor)
    {
        computer.Accept(visitor); // تحديث القيم

        double? cpu = null;
        double? gpu = null;

        foreach (var hw in computer.Hardware)
        {
            if (hw.HardwareType == HardwareType.Cpu)
                cpu ??= FindFirstTemperature(hw);

            if (hw.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel)
                gpu ??= FindFirstTemperature(hw);
        }

        // fallback لو CPU رجع null
        cpu ??= ReadCpuTempFromWmi();

        return (cpu, gpu);
    }

    // أول Sensor حرارة
    private static double? FindFirstTemperature(IHardware hw)
    {
        foreach (var s in hw.Sensors)
            if (s.SensorType == SensorType.Temperature && s.Value.HasValue)
                return s.Value;

        foreach (var sub in hw.SubHardware)
            foreach (var s in sub.Sensors)
                if (s.SensorType == SensorType.Temperature && s.Value.HasValue)
                    return s.Value;

        return null;
    }

    // WMI fallback (MSAcpi)
    private static double? ReadCpuTempFromWmi()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher(
                @"root\WMI",
                "SELECT * FROM MSAcpi_ThermalZoneTemperature"
            );

            foreach (ManagementObject obj in searcher.Get())
            {
                var temp = Convert.ToDouble(obj["CurrentTemperature"]);
                return (temp / 10) - 273.15;
            }
        }
        catch { }

        return null;
    }

    // CORS
    private static void AddCors(HttpListenerResponse res)
    {
        res.Headers["Access-Control-Allow-Origin"] = "*";
    }

    // Check Admin
    private static bool IsAdministrator()
    {
        using var id = WindowsIdentity.GetCurrent();
        return new WindowsPrincipal(id)
            .IsInRole(WindowsBuiltInRole.Administrator);
    }

    // Visitor pattern لتحديث الهاردوير
    private sealed class UpdateVisitor : IVisitor
    {
        public void VisitComputer(IComputer computer) => computer.Traverse(this);
        public void VisitHardware(IHardware hardware)
        {
            hardware.Update();
            foreach (var sub in hardware.SubHardware)
                sub.Accept(this);
        }
        public void VisitSensor(ISensor sensor) { }
        public void VisitParameter(IParameter parameter) { }
    }
}
